# Breast Tumor Segmentation
 This project was made with MATLAB. 
 
![Image description](1deschidere.png)
![Image description](2help.png)
![Image description](3incarcare.png)
![Image description](4kmeans.png)
![Image description](5fuzzy.png)
![Image description](6thresh.png)
![Image description](risc.png)
